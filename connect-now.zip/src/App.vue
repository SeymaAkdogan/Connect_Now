<template>
    <home/>
</template>

<script>
import home from '@/components/home'

export default {
    components :{
      home
    }
}
</script>

<style scoped>

</style>
